Cuckoo Filter
=============

A key-value filter using cuckoo hashing, substituting for bloom filter.

Usage
-----

```c
cd cuckoo_filter
make
./cockoo_db input_file output_file
```

Define `CUCKOO_DBG` in cuckoo_filter.h to open debug logging.
